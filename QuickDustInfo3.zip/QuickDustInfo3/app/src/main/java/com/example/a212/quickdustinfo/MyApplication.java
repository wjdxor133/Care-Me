package com.example.a212.quickdustinfo;

import android.app.Application;

public class MyApplication extends Application {

    @Override

    public void onCreate() {

        super.onCreate();



        Realm.init(this);

        RealmConfiguration config = new RealmConfiguration.Builder().build();

        Realm.setDefaultConfiguration(config);

    }

}