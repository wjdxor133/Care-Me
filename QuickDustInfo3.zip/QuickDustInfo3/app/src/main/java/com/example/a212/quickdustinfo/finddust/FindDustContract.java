package com.example.a212.quickdustinfo.finddust;

import com.example.a212.quickdustinfo.model.FineDust;

public class FindDustContract {
    interface View{
        void showFineDustResult(FineDust fineDust);
        void showLoadError(String message);
        void loadingStart();
        void loadingEnd();
        void reload(double lat, double lng);

    }
    interface UserActionsListener{
        void loadFineDustData();
    }
}
