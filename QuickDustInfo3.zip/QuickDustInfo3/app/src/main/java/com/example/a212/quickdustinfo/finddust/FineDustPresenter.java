package com.example.a212.quickdustinfo.finddust;

import com.example.a212.quickdustinfo.data.fineDustRepository;
import com.example.a212.quickdustinfo.model.FineDust;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class FineDustPresenter implements FindDustContract.UserActionsListener{
    private final fineDustRepository mRepository;
    /**
     *
     */
    private final FindDustContract.View mView;

    public FineDustPresenter(fineDustRepository repository,FindDustContract.View View) {
        this.mRepository = repository;
        this.mView=View;
    }

    @Override
    public void loadFineDustData(){

        if(mRepository.isAvailable()){
            mView.loadingStart();
            mRepository.getFindDustData(new Callback<FineDust>() {
                @Override
                public void onResponse(Call<FineDust> call, Response<FineDust> response) {
                    mView.showFineDustResult(response.body());
                    mView.loadingEnd();
                }

                @Override
                public void onFailure(Call<FineDust> call, Throwable t) {

                    mView.showLoadError(t.getLocalizedMessage());
                    mView.loadingEnd();
                }
            });
        }
    }

}
