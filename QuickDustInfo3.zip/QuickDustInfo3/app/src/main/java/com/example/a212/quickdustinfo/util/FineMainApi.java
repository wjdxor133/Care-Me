package com.example.a212.quickdustinfo.util;

import com.example.a212.quickdustinfo.model.FineDust;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Headers;
import retrofit2.http.Query;

public interface FineMainApi
{
    String BASE_URL= " http://api.weatherplanet.co.kr/";
    @Headers("6b200e091d1a4d7e83fb9b4732809b33")
    @GET("data/2.5/weather")
    Call<FineDust> getFineDust(@Query("lon") double longitude, @Query("lat")double latitude);


}
