package com.example.a212.quickdustinfo.data;

import com.example.a212.quickdustinfo.model.FineDust;

import retrofit2.Callback;

public interface fineDustRepository {
    boolean isAvailable();
    void getFindDustData(Callback<FineDust> callback);
}
