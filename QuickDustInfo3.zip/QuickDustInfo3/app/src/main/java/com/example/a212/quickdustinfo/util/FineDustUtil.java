package com.example.a212.quickdustinfo.util;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class FineDustUtil {
    private FineMainApi mGetApi;
    public FineDustUtil(){
        Retrofit mRetrofit = new Retrofit.Builder()
                .baseUrl(FineMainApi.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        mGetApi=mRetrofit.create(FineMainApi.class);
    }

    public FineMainApi getmGetApi() {
        return mGetApi;
    }
}
