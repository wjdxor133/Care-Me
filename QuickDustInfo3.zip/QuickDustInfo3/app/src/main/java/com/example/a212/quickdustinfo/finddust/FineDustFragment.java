package com.example.a212.quickdustinfo.finddust;

import android.app.Fragment;
import android.graphics.Color;
import android.os.Bundle;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.example.a212.quickdustinfo.R;

public class FineDustFragment extends Fragment{
    private TextView mLocationTextView;
    private TextView mDustTextView;
    private TextView mTimeTextView;
    private SwipeRefreshLayout mSwipeRefreshLayout;
    private FineDustPresenter mPresenter;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View view =inflater.inflate(R.layout.fragment_fine_dust,container,false);
        mLocationTextView =view.findViewById(R.id.result_location_text);
        mTimeTextView =view.findViewById(R.id.result_time_text);
        mDustTextView =view.findViewById(R.id.result_dust_text);

        if(savedInstanceState != null){
            //복원
            mLocationTextView.setText(savedInstanceState.getString("location"));
            mTimeTextView.setText(savedInstanceState.getString("time"));
            mDustTextView.setText(savedInstanceState.getString("dust"));

        }
        mSwipeRefreshLayout=view.findViewById(R.id.swipe_refresh_layout);
        mSwipeRefreshLayout.setColorSchemeColors(Color.RED, Color.YELLOW,Color.GREEN,Color.BLUE);
        mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                mPresenter.loadFineDustData();
            }
        });

        return view;

    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString("location",mLocationTextView.getText().toString());
        outState.putString("time",mTimeTextView.getText().toString());
        outState.putString("dust",mDustTextView.getText().toString());

    }
}
