package com.example.a212.quickdustinfo.data;

import com.example.a212.quickdustinfo.model.FineDust;
import com.example.a212.quickdustinfo.util.FineDustUtil;

import retrofit2.Callback;

public class LocationFineDustRepository implements fineDustRepository {



    private FineDustUtil mFineDustUtil;

    private double mLatitude;

    private double mLongitude;



    public LocationFineDustRepository(double lat, double lng) {

        mFineDustUtil = new FineDustUtil();

        mLatitude = lat;

        mLongitude = lng;

    }



    @Override

    public void getFineDustData(Callback callback) {

        mFineDustUtil.getApi().getFineDust(mLatitude, mLongitude).enqueue(callback);

    }



    @Override

    public boolean isAvailable() {

        if (mLatitude != 0.0 && mLongitude != 0.0) {

            return true;



        }

        return false;

    }

}
